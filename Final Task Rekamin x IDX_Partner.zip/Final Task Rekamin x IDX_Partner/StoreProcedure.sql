USE DWH;

CREATE PROCEDURE DailyTransaction
    @start_date DATE,
    @end_date DATE
AS
BEGIN
    SELECT 
        CONVERT(DATE,TransactionDate) AS TransactionDate,
        COUNT(*) AS TotalTransactions,
        SUM(Amount) AS TotalAmount
    FROM 
        FactTransaction
    WHERE 
        TransactionDate >= @start_date AND TransactionDate < DATEADD(DAY, 1, @end_date)
    GROUP BY 
        CONVERT(DATE,TransactionDate)
    ORDER BY 
        CONVERT(DATE,TransactionDate)
END

EXEC DailyTransaction @start_date = '2024-01-18', @end_date = '2024-01-20';

DROP PROCEDURE DailyTransaction;

CREATE PROCEDURE BalancePerCustomer @name VARCHAR(500) AS
BEGIN
    SELECT 
        dc.CustomerName,
		da.AccountType,
		da.Balance,
		Balance - COALESCE(SUM(CASE WHEN TransactionType = 'Deposit' THEN ft.amount ELSE -ft.amount END), 0) AS CurrentBalance
    FROM 
        DimAccount AS da
		INNER JOIN
		DimCustomer AS dc ON da.CustomerID = dc.CustomerID
		INNER JOIN
		FactTransaction AS ft ON da.AccountID = ft.AccountID
    WHERE 
		dc.CustomerName = @name AND da.Status = 'Active'
   GROUP BY 
        dc.CustomerName,
        da.AccountType,
        da.Balance
   ORDER BY 
        da.AccountType
END

EXEC BalancePerCustomer @name = 'Shelly Juwita';

DROP PROCEDURE BalancePerCustomer;


