CREATE DATABASE DWH;
USE DWH;

CREATE TABLE DimCustomer (
    CustomerID INT NOT NULL,
    CustomerName VARCHAR(50) NOT NULL,
    Address VARCHAR(100) NOT NULL,
    Age INT NOT NULL,
    Gender VARCHAR(10) NOT NULL,
    Email VARCHAR(50) NOT NULL,
	CityName VARCHAR(20) NOT NULL,
	StateName VARCHAR(20) NOT NULL,
    CONSTRAINT PKCustomerID PRIMARY KEY (CustomerID)
);

CREATE TABLE DimAccount (
    AccountID INT NOT NULL,
    CustomerID INT NOT NULL,
    AccountType VARCHAR(50) NOT NULL,
    Balance INT NOT NULL,
    DateOpened DATETIME2(0),
    Status VARCHAR(20) NOT NULL,
    CONSTRAINT PKAccountID PRIMARY KEY (AccountID),
    FOREIGN KEY (CustomerID) REFERENCES DimCustomer(CustomerID)
);

CREATE TABLE DimBranch (
    BranchID INT NOT NULL,
    BranchName VARCHAR(50) NOT NULL,
    BranchLocation VARCHAR(100) NOT NULL,
    CONSTRAINT PKBranchID PRIMARY KEY (BranchID)
);

CREATE TABLE FactTransaction (
    TransactionID INT NOT NULL,
    AccountID INT NOT NULL,
    TransactionDate DATETIME2(0) NOT NULL,
    Amount INT NOT NULL,
    TransactionType VARCHAR(50) NOT NULL,
    BranchID INT NOT NULL,
    CONSTRAINT PKTransactionID PRIMARY KEY (TransactionID),
    FOREIGN KEY (AccountID) REFERENCES DimAccount(AccountID),
    FOREIGN KEY (BranchID) REFERENCES DimBranch(BranchID)
);

SELECT * FROM DimCustomer;
SELECT * FROM DimAccount;
SELECT * FROM DimBranch;
SELECT * FROM FactTransaction;